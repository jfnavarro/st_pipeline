#ifndef TIME_FUNCTIONS_DEF
#define TIME_FUNCTIONS_DEF
#include <string>
#include <time.h>

string timeMonthDayTime();
string timeMonthDayTime(time_t &rawTime);

#endif
