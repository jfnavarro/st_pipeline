#include "IncludeDefine.h"
intSWscore alignSmithWaterman(char *R, uint rL, char *G, uint gL, intSWscore pMatch, intSWscore pMismatch, intSWscore pGapOpen, intSWscore pGapExtend, char* T, uint Tsize, Transcript &trA);
