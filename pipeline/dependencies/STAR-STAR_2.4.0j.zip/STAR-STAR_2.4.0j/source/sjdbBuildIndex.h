#ifndef CODE_sjdbBuildIndex
#define CODE_sjdbBuildIndex

#include "SjdbClass.h"
#include "Parameters.h"
#include "PackedArray.h"

void sjdbBuildIndex (Parameters *P, char *G, PackedArray &SA, PackedArray &SA2, PackedArray &SAi);

#endif
