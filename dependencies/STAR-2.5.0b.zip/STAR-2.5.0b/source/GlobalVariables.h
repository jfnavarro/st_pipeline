#ifndef GLOBAL_VARIABLES_DEF
#define GLOBAL_VARIABLES_DEF

#include "ThreadControl.h"
extern Stats g_statsAll;
extern ThreadControl g_threadChunks;

#endif

