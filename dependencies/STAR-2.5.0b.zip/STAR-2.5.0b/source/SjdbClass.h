#ifndef DEF_SjdbClass
#define DEF_SjdbClass

#include "IncludeDefine.h"
#include "Parameters.h"

class SjdbClass {
public:
    vector <string> chr;
    vector <uint> start,end;    
    vector <char> str;
    vector <uint8_t> priority;
};

#endif
